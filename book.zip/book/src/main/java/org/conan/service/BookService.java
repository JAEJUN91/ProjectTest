package org.conan.service;

import java.util.List;

import org.conan.domain.BookVO;

public interface BookService {
	public List<BookVO> getList();
	public BookVO getBook(int bookId);
}
