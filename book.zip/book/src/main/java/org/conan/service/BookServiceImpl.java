package org.conan.service;

import java.util.List;

import org.conan.domain.BookVO;
import org.conan.mapper.BookMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.Setter;

@Service
public class BookServiceImpl implements BookService{
	
	@Setter(onMethod_ = {@Autowired})
	private BookMapper mapper;
	
	@Override
	public List<BookVO> getList() {
		List<BookVO> list = mapper.getList();
		return list;
	}
	
	@Override
	public BookVO getBook(int bookId) {
		BookVO book = mapper.getBook(bookId);
		return book;
	}
}
